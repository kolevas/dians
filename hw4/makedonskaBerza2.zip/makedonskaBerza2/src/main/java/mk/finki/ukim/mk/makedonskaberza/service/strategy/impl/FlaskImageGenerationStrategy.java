package mk.finki.ukim.mk.makedonskaberza.service.strategy.impl;

import mk.finki.ukim.mk.makedonskaberza.service.strategy.ImageGenerationStrategy;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;



@Service
public class FlaskImageGenerationStrategy implements ImageGenerationStrategy {

    private final RestTemplate restTemplate;

    public FlaskImageGenerationStrategy(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public String generateImage(String issuer, String prikaz, String interval) {
        String flaskUrl = "http://localhost:5000/generate";
        String jsonBody = String.format("{\"issuer\": \"%s\", \"interval\": \"%s\", \"prikaz\": \"%s\"}", issuer, interval, prikaz);

        // Prepare the HTTP request
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);

        try {
            ResponseEntity<Resource> response = restTemplate.exchange(
                    flaskUrl,
                    HttpMethod.POST,
                    entity,
                    Resource.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                // Save the image to a file
                try (InputStream inputStream = response.getBody().getInputStream()) {
                    Path outputPath = Paths.get(String.format("src/main/resources/static/images/image_from_flask_%s_%s_%s.png", issuer, prikaz, interval));
                    Files.createDirectories(outputPath.getParent());
                    Files.copy(inputStream, outputPath, StandardCopyOption.REPLACE_EXISTING);
                    return String.format("/images/image_from_flask_%s_%s_%s.png", issuer, prikaz, interval);
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new RuntimeException("Error while saving the image", e);
                }
            } else {
                System.out.println("Failed to fetch the image. Status: " + response.getStatusCode());
                throw new RuntimeException("Failed to fetch image from Flask service");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error during the HTTP request to Flask service", e);
        }
    }
}
