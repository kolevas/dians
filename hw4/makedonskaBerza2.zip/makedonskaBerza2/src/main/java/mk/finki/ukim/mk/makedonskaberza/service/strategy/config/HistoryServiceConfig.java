package mk.finki.ukim.mk.makedonskaberza.service.strategy.config;

import mk.finki.ukim.mk.makedonskaberza.repository.HistoryRepository;
import mk.finki.ukim.mk.makedonskaberza.service.strategy.PriceCalculationStrategy;
import mk.finki.ukim.mk.makedonskaberza.service.strategy.TransactionCountingStrategy;
import mk.finki.ukim.mk.makedonskaberza.service.strategy.impl.AvgMaxPriceStrategy;
import mk.finki.ukim.mk.makedonskaberza.service.strategy.impl.AvgMinPriceStrategy;
import mk.finki.ukim.mk.makedonskaberza.service.strategy.context.HistoryServiceContext;
import mk.finki.ukim.mk.makedonskaberza.service.strategy.impl.TransactionsLastYearStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HistoryServiceConfig {

    @Bean
    public HistoryServiceContext historyServiceContext(HistoryRepository repository) {
        PriceCalculationStrategy avgMaxPriceStrategy = new AvgMaxPriceStrategy(repository);
        PriceCalculationStrategy avgMinPriceStrategy = new AvgMinPriceStrategy(repository);
        TransactionCountingStrategy transactionsLastYearStrategy = new TransactionsLastYearStrategy(repository);

        return new HistoryServiceContext(avgMaxPriceStrategy, avgMinPriceStrategy, transactionsLastYearStrategy);
    }
}
