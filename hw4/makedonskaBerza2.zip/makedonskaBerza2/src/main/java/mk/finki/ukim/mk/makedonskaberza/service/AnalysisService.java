package mk.finki.ukim.mk.makedonskaberza.service;

import java.util.List;

public interface AnalysisService {
//    List<String> getNames();

    List<String> getParams();

    List<String> getIntervals();

    String getImg(String issuer, String prikaz, String interval);
}
