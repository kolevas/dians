package mk.finki.ukim.mk.makedonskaberza.service.strategy.impl;

import mk.finki.ukim.mk.makedonskaberza.repository.HistoryRepository;
import mk.finki.ukim.mk.makedonskaberza.service.strategy.PriceCalculationStrategy;
import mk.finki.ukim.mk.makedonskaberza.model.IssuerHistory;
import java.sql.Date;
import java.time.LocalDateTime;
public class AvgMinPriceStrategy implements PriceCalculationStrategy {

    private final HistoryRepository repository;

    public AvgMinPriceStrategy(HistoryRepository repository) {
        this.repository = repository;
    }

    @Override
    public double calculate(String code) {
        return repository.findIssuerHistoryByIssuerCodeIgnoreCase(code).stream()
                .filter(ih -> {
                    Date entryDate = ih.getEntryDate();
                    if (entryDate == null) {
                        return false;
                    }
                    LocalDateTime ihDate = entryDate.toLocalDate().atStartOfDay();
                    return ihDate.isAfter(LocalDateTime.now().minusYears(1));
                })
                .mapToDouble(IssuerHistory::getMinimumPrice)
                .average()
                .orElse(0);
    }
}