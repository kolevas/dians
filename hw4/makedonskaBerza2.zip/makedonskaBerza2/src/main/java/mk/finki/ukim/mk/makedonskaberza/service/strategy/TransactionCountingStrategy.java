package mk.finki.ukim.mk.makedonskaberza.service.strategy;

public interface TransactionCountingStrategy {
    long countTransactions(String code);
}
