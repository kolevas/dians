package mk.finki.ukim.mk.makedonskaberza.service.strategy;


import org.springframework.core.io.Resource;

public interface ImageProcessingStrategy {
    void processImage(Resource resource, String issuerCode);
}
