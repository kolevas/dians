package mk.finki.ukim.mk.makedonskaberza.service.strategy;

public interface ImageGenerationStrategy {
    String generateImage(String issuer, String prikaz, String interval);
}