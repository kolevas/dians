package mk.finki.ukim.mk.makedonskaberza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MakedonskaBerzaApplicationTests {

    @Test
    void contextLoads() {
    }

}
