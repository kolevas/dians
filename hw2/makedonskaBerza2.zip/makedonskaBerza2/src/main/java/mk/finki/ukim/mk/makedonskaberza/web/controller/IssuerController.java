package mk.finki.ukim.mk.makedonskaberza.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.finki.ukim.mk.makedonskaberza.model.Issuer;
import mk.finki.ukim.mk.makedonskaberza.model.IssuerHistory;
import mk.finki.ukim.mk.makedonskaberza.service.HistoryService;
import mk.finki.ukim.mk.makedonskaberza.service.IssuerService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/issuer")
public class IssuerController {
    private final IssuerService issuerService;
    private final HistoryService historyService;

    public IssuerController(IssuerService issuerService, HistoryService historyService) {
        this.issuerService = issuerService;
        this.historyService = historyService;
    }

//    @GetMapping
//    public String getTopIssuersByAveragePrice(@RequestParam(defaultValue = "5") int count, Model model) {
//        List<IssuerHistory> issuersHistory = historyService.getTopCompanies(count);  // Повик на сервисот
//        model.addAttribute("history", issuersHistory);  // Проследување на податоците во моделот
//        return "index.html";  // Враќање на главната страница (Thymeleaf шаблон)
//    }

    @GetMapping("/rezultati_prebaruvanje")
    public String rezultatiPrebaruvanje(@RequestParam(required = false) String searchName,
                                        Model model,
                                        HttpServletRequest req) {
        searchName = req.getParameter("searchName");
        List<IssuerHistory> companies;
        // Check if search text or rating is provided
       // if ((searchName == null || searchName.isEmpty())) {
           // companies = issuerService.GetAllIssuers();

        companies = historyService.GetIssuerHistoryByCode(searchName);

        model.addAttribute("companies", companies);
        return "rezultati-prebaruvanje";
    }

    @GetMapping("/sporedi")
    public String sporedba(HttpServletRequest request) {
        return "sporedba-kompanii";
    }

}
