package mk.finki.ukim.mk.makedonskaberza.service.impl;

import mk.finki.ukim.mk.makedonskaberza.model.Issuer;
import mk.finki.ukim.mk.makedonskaberza.repository.IssuerRepository;
import mk.finki.ukim.mk.makedonskaberza.service.IssuerService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IssuerServiceImpl implements IssuerService {
    private final IssuerRepository repository;

    public IssuerServiceImpl(IssuerRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<Issuer> GetAllIssuers() { return this.repository.findAll();    }

    public List<Issuer> GetIssuerByName(String issuername) {return repository.findByIssuername(issuername);}

    public Issuer GetIssuerByCode(String issuercode) {return repository.findByIssuercode(issuercode);}

    //search - ot (treba da bide spored podatoci od baza)
    @Override
    public List<Issuer> searchCompanies(String name) {
        return repository.findByIssuername(name);
    }

}
