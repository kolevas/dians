package mk.finki.ukim.mk.makedonskaberza.repository;

import mk.finki.ukim.mk.makedonskaberza.model.Issuer;
import mk.finki.ukim.mk.makedonskaberza.model.IssuerHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.awt.print.Pageable;
import java.sql.Date;
import java.util.List;

public interface HistoryRepository extends JpaRepository<IssuerHistory, Integer> {
    public List<IssuerHistory> findByIssuerCodeOrderByEntryDateDesc(String code);
    public List<IssuerHistory> findByIssuerCodeAndEntryDateBetweenOrderByEntryDateDesc(String code, Date startDate, Date endDate);
    @Query("SELECT ih FROM IssuerHistory ih ORDER BY ih.averagePrice DESC LIMIT 5")
    List<IssuerHistory> findTopByAveragePriceOrderByEntryDate(@Param("count") int count);
    public List<IssuerHistory> findIssuerHistoryByIssuerCode(String issuercode);
}
