package mk.finki.ukim.mk.makedonskaberza.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.finki.ukim.mk.makedonskaberza.model.Issuer;
import mk.finki.ukim.mk.makedonskaberza.model.IssuerHistory;
import mk.finki.ukim.mk.makedonskaberza.service.HistoryService;
import mk.finki.ukim.mk.makedonskaberza.service.IssuerService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/history")
public class HistoryController {
    private final HistoryService historyService;
    private final IssuerService issuerService;

    public HistoryController(HistoryService historyService, IssuerService issuerService) {
        this.historyService = historyService;
        this.issuerService = issuerService;
    }

    @GetMapping
    public String getTopIssuersByAveragePrice(@RequestParam(defaultValue = "5") int count, Model model) {
        List<IssuerHistory> issuersHistory = historyService.getTopCompanies(count);  // Повик на сервисот
        model.addAttribute("history", issuersHistory);  // Проследување на податоците во моделот
        return "index.html";  // Враќање на главната страница (Thymeleaf шаблон)
    }


    @GetMapping("/detali_kompanija/{code}")
    public String detali_kompanija(@PathVariable String code, HttpServletRequest request, Model model) {
        List<IssuerHistory> issuerHistory = historyService.GetIssuerHistoryByCode(code);
        Issuer issuer = issuerService.GetIssuerByCode(code);

        model.addAttribute("issuer", issuer);
        model.addAttribute("history", issuerHistory);
        return "detali-kompanija";
    }

    @GetMapping("/detali_izvestaj/{code}")
    public String detaliIzvaestaj(@PathVariable String code, HttpServletRequest request, Model model) {

        Issuer issuer = issuerService.GetIssuerByCode(code);
        model.addAttribute("issuer", issuer);

        return "detali-izvestaj.html";
    }
}
