package mk.finki.ukim.mk.makedonskaberza.repository;

import mk.finki.ukim.mk.makedonskaberza.model.Issuer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface IssuerRepository extends JpaRepository<Issuer, String> {
    public List<Issuer> findByIssuername(String issuername);
    public Issuer findByIssuercode(String issuercode);


}
