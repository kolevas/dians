package mk.finki.ukim.mk.makedonskaberza.service.impl;

import mk.finki.ukim.mk.makedonskaberza.model.Issuer;
import mk.finki.ukim.mk.makedonskaberza.model.IssuerHistory;
import mk.finki.ukim.mk.makedonskaberza.repository.HistoryRepository;
import mk.finki.ukim.mk.makedonskaberza.service.HistoryService;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.awt.print.Pageable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class HistoryServiceImpl implements HistoryService {
    private final HistoryRepository repository;

    public HistoryServiceImpl(HistoryRepository repository) {
        this.repository = repository;
    }


    @Override
    public List<IssuerHistory> GetHistoryForCompany(String issuerCode) {
        return this.repository.findByIssuerCodeOrderByEntryDateDesc(issuerCode);
    }

    @Override
    public List<IssuerHistory> GetHistoryForCompany(String issuerCode, Date startDate, Date endDate) {
        return this.repository.findByIssuerCodeAndEntryDateBetweenOrderByEntryDateDesc(issuerCode, startDate, endDate);
    }

    public List<IssuerHistory> GetIssuerHistoryByCode(String issuercode) {return repository.findIssuerHistoryByIssuerCode(issuercode);}


    @Override
    public List<IssuerHistory> getTopCompanies(int count) {
        List<IssuerHistory> allCompanies = repository.findTopByAveragePriceOrderByEntryDate(count);
        // Limit to the top 'count' companies
//        return allCompanies.stream()
//                .limit(count)
//                .toList();
        return allCompanies;
    }



}
