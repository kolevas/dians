package mk.finki.ukim.mk.makedonskaberza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MakedonskaBerzaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MakedonskaBerzaApplication.class, args);
    }

}
